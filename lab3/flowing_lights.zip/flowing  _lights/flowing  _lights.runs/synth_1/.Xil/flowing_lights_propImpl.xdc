set_property SRC_FILE_INFO {cfile:{C:/Users/Administrator/flowing  _lights/flowing  _lights.srcs/constrs_1/new/constraints.xdc} rfile:{../../../flowing  _lights.srcs/constrs_1/new/constraints.xdc} id:1} [current_design]
set_property src_info {type:XDC file:1 line:1 export:INPUT save:INPUT read:READ} [current_design]
set_property -dict { PACKAGE_PIN Y18 IOSTANDARD LVCMOS33 } [get_ports clk];
set_property src_info {type:XDC file:1 line:2 export:INPUT save:INPUT read:READ} [current_design]
set_property -dict { PACKAGE_PIN R1 IOSTANDARD LVCMOS33 } [get_ports rst];
set_property src_info {type:XDC file:1 line:3 export:INPUT save:INPUT read:READ} [current_design]
set_property -dict { PACKAGE_PIN W4 IOSTANDARD LVCMOS33 } [get_ports freq_ctrl];
set_property src_info {type:XDC file:1 line:4 export:INPUT save:INPUT read:READ} [current_design]
set_property -dict { PACKAGE_PIN R4 IOSTANDARD LVCMOS33 } [get_ports dir_ctrl];
set_property src_info {type:XDC file:1 line:5 export:INPUT save:INPUT read:READ} [current_design]
set_property -dict { PACKAGE_PIN U6 IOSTANDARD LVCMOS33 } [get_ports model_set];
set_property src_info {type:XDC file:1 line:6 export:INPUT save:INPUT read:READ} [current_design]
set_property -dict { PACKAGE_PIN A21 IOSTANDARD LVCMOS33 } [get_ports {leds[0]}];
set_property src_info {type:XDC file:1 line:7 export:INPUT save:INPUT read:READ} [current_design]
set_property -dict { PACKAGE_PIN E22 IOSTANDARD LVCMOS33 } [get_ports {leds[1]}];
set_property src_info {type:XDC file:1 line:8 export:INPUT save:INPUT read:READ} [current_design]
set_property -dict { PACKAGE_PIN D22 IOSTANDARD LVCMOS33 } [get_ports {leds[2]}];
set_property src_info {type:XDC file:1 line:9 export:INPUT save:INPUT read:READ} [current_design]
set_property -dict { PACKAGE_PIN E21 IOSTANDARD LVCMOS33 } [get_ports {leds[3]}];
set_property src_info {type:XDC file:1 line:10 export:INPUT save:INPUT read:READ} [current_design]
set_property -dict { PACKAGE_PIN D21 IOSTANDARD LVCMOS33 } [get_ports {leds[4]}];
set_property src_info {type:XDC file:1 line:11 export:INPUT save:INPUT read:READ} [current_design]
set_property -dict { PACKAGE_PIN G21 IOSTANDARD LVCMOS33 } [get_ports {leds[5]}];
set_property src_info {type:XDC file:1 line:12 export:INPUT save:INPUT read:READ} [current_design]
set_property -dict { PACKAGE_PIN G22 IOSTANDARD LVCMOS33 } [get_ports {leds[6]}];
set_property src_info {type:XDC file:1 line:13 export:INPUT save:INPUT read:READ} [current_design]
set_property -dict { PACKAGE_PIN F21 IOSTANDARD LVCMOS33 } [get_ports {leds[7]}];
